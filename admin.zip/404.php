<?php
require "conn.php";
require "partition/header.php";

?>

<body>

  <?php
  require "partition/nav.php";
  ?>


  <div class="container-fluid">


    <h1>404 Not Found</h1>
    <hr>
    <div class="row produk">
         <div class="col-lg-12 col-xs-12">
         <h4>Data yang anda cari tidak ditemukan. Silahkan cari ulang.</h4>
        </div>
    </div>



  </div>

  <?php
  require "partition/footer.php";
  ?>

</body>
</html>
